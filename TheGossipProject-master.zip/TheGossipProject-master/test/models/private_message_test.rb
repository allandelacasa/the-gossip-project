require 'test_helper'

class PrivateMessageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
