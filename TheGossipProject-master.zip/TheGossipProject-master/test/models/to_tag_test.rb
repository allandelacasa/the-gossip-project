require 'test_helper'

class ToTagTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
