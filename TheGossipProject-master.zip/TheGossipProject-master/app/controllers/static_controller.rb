class StaticController < ApplicationController

def index
end

def index_contact
end
    
end